// CARPETA DEL API

// const servidor = '/bloque7_backend'
const servidor = ''

// conexion 1 a hosting

const host = 'www.hatogrillteconsiente.com'
// const host = '200.44.250.20'
const user = 'hatogril_pollahipica'
const password = '*pollahipica*'
const database = 'hatogril_polla'
const message = 'BD App ' + database + ' está conectada'

module.exports = {
    servidor,
    host,
    user,
    password,
    database,
    message
};